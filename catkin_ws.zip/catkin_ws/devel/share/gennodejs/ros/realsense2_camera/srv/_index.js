
"use strict";

let DeviceInfo = require('./DeviceInfo.js')

module.exports = {
  DeviceInfo: DeviceInfo,
};
